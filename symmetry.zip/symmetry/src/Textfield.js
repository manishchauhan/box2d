(function() {

function TextField(label,color,html) {
	this.Container_constructor();
	this.html=html;
	this.color = color;
	this.label = label;
	
	this.setup();
}
var p = createjs.extend(TextField, createjs.Container);
//global variables
var labelText;
var htmllabelText;
var html;
var htmlText;
//global function
p.createDOMElement=function()
{
	this.htmlText = document.createElement('div');
	this.htmlText.innerHTML =this.label;
	this.htmlText.id = 'ab';
	this.htmlText.style.height = '50px';
	this.htmlText.style.width = '200px';
	this.htmlText.style.position = "absolute";
	this.htmlText.style.top = 0;
	this.htmlText.style.left = 0;
	document.body.appendChild(this.htmlText);
}
p.setup = function() {
	if(this.html)
	{
		this.createDOMElement();
		this.htmllabelText= new createjs.DOMElement(this.htmlText);
		this.addChild(this.htmllabelText);
	}
	else
	{
		this.labelText = new createjs.Text(this.label, "20px Arial", "#000");
		this.labelText.textBaseline = "top";
		this.labelText.textAlign = "center";
		var width = this.labelText.getMeasuredWidth()+30;
		var height = this.labelText.getMeasuredHeight()+20;
		this.labelText.x = width/2;
		this.labelText.y = 10;
		var background = new createjs.Shape();
     	background.graphics.beginFill(this.color).drawRoundRect(0,0,width,height,10);
     	this.addChild(background, this.labelText); 
		
	}

} ;



p.enableMouseEvents=function (enable)
{

	if(enable)
	{
		this.on("click", this.handleClick);
		this.on("rollover", this.handleRollOver);
		this.on("rollout", this.handleRollOver);
		this.cursor = "pointer";

		this.mouseChildren = false;
	
		this.offset = Math.random()*10;
		this.count = 0;
	}
}
p.handleClick = function (event) {
	alert("You clicked on a button: "+this.labelText.text);
} ;

p.handleRollOver = function(event) {       
	this.alpha = event.type == "rollover" ? 0.4 : 1;
};

window.TextField = createjs.promote(TextField, "Container");
}());