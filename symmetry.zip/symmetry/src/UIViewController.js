/**
 * ...
 * @author manish
 */
 //global vars 

(function() {
	
	 var loader;
	 var init;
	 var stage;
	//all local properties

	//all local properties
	
	
	function UIViewController(){}
			
			
			UIViewController.init = function(){
			
			init = new UIViewController();
			init.addAllcanvas();
			init.addGameStage();
		}
	//adding canavs for html rendering *********************************************************************************
	UIViewController.prototype.addAllcanvas=function()
	{
			
			//@canvas responsible for all drawing 
			canvas=document.createElement('canvas');
			canvas.setAttribute('style', 'position: fixed; top: 0px; left:0px;');
			canvas.width=1000;
			canvas.height=625;                     
			document.body.appendChild(canvas);
			//@addDebuglayer() function which is responsible for physics debug drawing
			 
			
	}
	//show hide  Physics
	UIViewController.prototype.showPhysics=function(status)
	{
		if(status && debugCanvas)
		{
				document.body.appendChild(debugCanvas);
		}
		else if(!status && debugCanvas)
		{
				document.body.removeChild(debugCanvas);
				debugCanvas=null;
		}
		
	}
	//adding stage to the game
	UIViewController.prototype.addGameStage=function()
	{
		stage = new createjs.Stage(canvas);
		stage.autoClear = true;
		stage.snapToPixelsEnabled=true;
		stage.enableMouseOver();
		stage.enableDOMEvents(true);
		createjs.Touch.enable(stage);
		stage.mouseChildren=false;
		//Scene2.init(stage);	
		
		loadJson();
	}
	//-------------------------------------------------------------just for check need to be removed----------------------------------------------------------------------------------------
	function loadJson()
	{
		var queue = new createjs.LoadQueue(true);
		queue.loadManifest({src:"bin/dataSource/json/gameData1.json", type: "manifest"});
		queue.on("fileload", handlejsonFileLoad, this);
		queue.on("complete", handlejsonComplete, this);
	}
	function handlejsonFileLoad(evt)
	{
		
		gameData=evt.result;
		LoadGraphicsAndSounds();
	}
	function handlejsonComplete(evt)
	{

	
	}
	function handlejsonComplete(evt)
	{
	   
	}
	function LoadGraphicsAndSounds()
	{	loader =new Preloader(gameData["gameData"]["manifest"], init)
		loader.x=0;
		loader.y=0;
		stage.addChild(loader);
		stage.update();
	}
	UIViewController.prototype.allLoadingDone=function()
	{
		stage.update();
		init.gotoandPlayLevel();
		//console.log(gameData["gameData"]["manifest"]);
	//	updateStage();
		
	}
	//-------------------------------------------------------------just for check need to be removed----------------------------------------------------------------------------------------
	//update level per game
	UIViewController.prototype.updateLevel=function()
	{
		//update level by one
		currentLevel++;
	}
	
	UIViewController.prototype.levelCompleted=function()
	{
		
	}
	//move game to the next level
	UIViewController.prototype.gotoandPlayLevel=function()
	{
	
			//remove all shapes from the stage
			stage.removeAllChildren();
			//reset all variables 
			resetAllGamevariables();
			addDebuglayer();
			var physicsClass=window[("Scene"+currentLevel)];
			physicsClass.init(stage,init);
			init.showPhysics(false);
	}
	//adding addDebuglayer the game
	function addDebuglayer()
	{
		debugCanvas = document.createElement('canvas');
		debugCanvas.setAttribute('style', 'position: fixed; top: 0px; left:0px;');
		debugCanvas.width=1000;
		debugCanvas.height=625;
		document.body.appendChild(debugCanvas);
	}
	window.UIViewController = UIViewController;
})();