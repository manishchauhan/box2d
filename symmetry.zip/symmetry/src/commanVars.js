/**
 * ...
 * @author manish
 */
 //box2d class;
	 var currentLevel=1;
	var canvas;
	var debugCanvas;
	var b2d = {
		b2Vec2 : Box2D.Common.Math.b2Vec2,
		b2BodyDef : Box2D.Dynamics.b2BodyDef,
		b2Body : Box2D.Dynamics.b2Body,
		b2FixtureDef : Box2D.Dynamics.b2FixtureDef,
		b2Fixture : Box2D.Dynamics.b2Fixture,
		b2World : Box2D.Dynamics.b2World,
		b2MassData : Box2D.Collision.Shapes.b2MassData,
		b2PolygonShape : Box2D.Collision.Shapes.b2PolygonShape,
		b2CircleShape : Box2D.Collision.Shapes.b2CircleShape,
		b2DebugDraw : Box2D.Dynamics.b2DebugDraw,
		ContactListener : Box2D.Dynamics.b2ContactListener,
		Manifold: Box2D.Collision.b2WorldManifold
	};
	var gameData;
var world;
var WORLD_SCALE=32.0;
//game comman variables
//box2d bodies
var bodies=[];
//total bodies which need to be distoryed
var numberOfbodies=0;
//number of bodies which user distoryed
var bodiesDistroyed=0;
//collding bodies
var collideBodies=0;
var totalcollideBodies=0;
//init varaibles
var AllbodiesDistroyed=false;
var AllbodiesCollide=false;
var levelCleared=false;

function resetAllGamevariables()
{
	//box2d bodies
	bodies=[];
	//total bodies which need to be distoryed
	numberOfbodies=0;
	//number of bodies which user distoryed
	bodiesDistroyed=0;
	//collding bodies
	collideBodies=0;
	totalcollideBodies=0;
	//init varaibles
	AllbodiesDistroyed=false;
	AllbodiesCollide=false;
	levelCleared=false;
	//console.log(collideBodies);
}