(function() {
//alignment of textfield
//label for the textfield
function colorText(maxWidth,align,label) {
	
	this.textArray=new Array();
	this.align=align;
	this.maxWidth=maxWidth;
	this.Container_constructor();
	this.label = label;
	this.textContent=false;
	this.totalContainerWidth=0;
	this.setup();
}
var p = createjs.extend(colorText, createjs.Container);
p.setup = function() {
	this.textContainer = new createjs.Container();
	this.addChild(this.textContainer); 
	//adding text  
	this.addText();
};
p.addText= function()
{
		if(this.align=="left")
		{
				this.setupForLeft();
		}
		else if(this.align=="center")
		{
				this.setupForCenter();
		}
		else if(this.align=="right")
		{
				this.setupForright();
		}
}
p.setupForLeft=function()
{
				var res = this.label.split(" ");
				var maxWidth=0;
				var height=0;
				for(var i=0;i<res.length;i++)
				{
					var text = new createjs.Text("", "20px Arial", "#fff");
					if(res[i].toString()=="#")
					{
						height+=30;
						maxWidth=0;
						text.text=" ";
					}
					else
					{
						var textObject=concatString(res[i].toString());
						text.text=" "+textObject.stringData;
					}
					if(textObject.constant)
					{
						text.color=textObject.colorCode;
					}
					else
					{
						text.color="#000";
					}
					
					text.x=maxWidth;
					text.y=height;
					maxWidth+=text.getBounds().width;
					this.textContainer.addChild(text);
					this.textArray.push(text);
				}
}
p.setupForCenter=function()
{
				
				var textArray=new Array();
				var res = this.label.split(" ");
				var maxWidth=0;
				var height=0;
				for(var i=0;i<res.length;i++)
				{
					var text = new createjs.Text("", "20px Arial", "#fff");
					if(res[i].toString()=="#")
					{
						this.textContent=true;
						height+=30;
						maxWidth=0;
						text.text=" ";
					}
					else
					{
						var textObject=concatString(res[i].toString());
						text.text=" "+textObject.stringData;
					}
					if(textObject.constant)
					{
						text.color=textObject.colorCode;
					}
					else
					{
						text.color="#000";
					}
					
					text.x=maxWidth;
					text.y=height;
					if(!this.textContent)
					{
						this.totalContainerWidth+=maxWidth;
					}
					maxWidth+=text.getBounds().width;
					this.textContainer.addChild(text);
					this.textArray.push(text);
					
				}
				//center in
				for(var i=0;i<this.textArray.length;i++)
				{
						this.textArray[i].x+=(this.maxWidth/2)-(this.totalContainerWidth/2);
				}
}
//handling regular expression
function concatString(_txt)
{
				var dataObject={}
				var constant=false;
				var mytext=_txt;
				var colorCode=null;
				var bold=null;
				var italic=null;
				//fetching value from a string in JAVASCRIPT
				var colorCode="";
				var wholetxt = _txt;
				wholetxt= wholetxt.split('{');
				for (var i = 1; i < wholetxt.length; i++) {
					
					colorCode=wholetxt[i].split('}')[0];
					//console.log(colorCode[0]);
					switch(colorCode[0])
					{
						case "#":
						colorCode=colorCode;	
						break;
						
						case "B":
						bold=colorCode;	
						
						break;
						
						case "I":
						italic=colorCode;
						
						break;
					}
				}	
				var result = _txt.replace(/(\{.*?\}) */g, '');
				
				if(mytext!=result)
				{
					constant=true;
				}
				
				dataObject.constant=constant;
				dataObject.stringData=result;
				//color code-----------------------------------------------------------------------------
				dataObject.colorCode=colorCode;
				//bold-----------------------------------------------------------------------------
				dataObject.bold=bold;
				//italic-----------------------------------------------------------------------------
				dataObject.italic=italic;
				
				return dataObject;
}
			
window.colorText = createjs.promote(colorText, "Container");
}());