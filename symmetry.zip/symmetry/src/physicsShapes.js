	/*
	var b2dstarPolygon={"POLYGON":

												// vertexes of decomposed polygons
												[

													[   new b2d.b2Vec2(93/WORLD_SCALE, 77/WORLD_SCALE)  ,  new b2d.b2Vec2(66/WORLD_SCALE, 96/WORLD_SCALE)  ,  new b2d.b2Vec2(40/WORLD_SCALE, 77/WORLD_SCALE)  ,  new b2d.b2Vec2(49/WORLD_SCALE, 45/WORLD_SCALE)  ,  new b2d.b2Vec2(82/WORLD_SCALE, 45/WORLD_SCALE)  ,  new b2d.b2Vec2(130/WORLD_SCALE, 47/WORLD_SCALE)  ] ,
													[   new b2d.b2Vec2(49/WORLD_SCALE, 45/WORLD_SCALE)  ,  new b2d.b2Vec2(40/WORLD_SCALE, 77/WORLD_SCALE)  ,  new b2d.b2Vec2(2/WORLD_SCALE, 47/WORLD_SCALE)  ] ,
													[   new b2d.b2Vec2(82/WORLD_SCALE, 45/WORLD_SCALE)  ,  new b2d.b2Vec2(49/WORLD_SCALE, 45/WORLD_SCALE)  ,  new b2d.b2Vec2(66/WORLD_SCALE, 0/WORLD_SCALE)  ] ,
													[   new b2d.b2Vec2(66/WORLD_SCALE, 96/WORLD_SCALE)  ,  new b2d.b2Vec2(93/WORLD_SCALE, 77/WORLD_SCALE)  ,  new b2d.b2Vec2(107/WORLD_SCALE, 123/WORLD_SCALE)  ] ,
													[   new b2d.b2Vec2(40/WORLD_SCALE, 77/WORLD_SCALE)  ,  new b2d.b2Vec2(66/WORLD_SCALE, 96/WORLD_SCALE)  ,  new b2d.b2Vec2(26/WORLD_SCALE, 125/WORLD_SCALE)  ]
												]};
												
	
	var b2dlevel345={"POLYGON":
		[
											 [   new b2d.b2Vec2(2/WORLD_SCALE, 31/WORLD_SCALE)  ,  new b2d.b2Vec2(1/WORLD_SCALE, 4/WORLD_SCALE)  ,  new b2d.b2Vec2(36/WORLD_SCALE, 4/WORLD_SCALE)  ],
											 [   new b2d.b2Vec2(105/WORLD_SCALE, 30/WORLD_SCALE)  ,  new b2d.b2Vec2(105/WORLD_SCALE, 4/WORLD_SCALE)  ,  new b2d.b2Vec2(216/WORLD_SCALE, 4/WORLD_SCALE)  ]
                                            
											]};
											
	var b2dlevel345F={"POLYGON":
		    

                                              [
												 [   new b2d.b2Vec2(6/WORLD_SCALE, 33/WORLD_SCALE)  ,  new b2d.b2Vec2(5/WORLD_SCALE, 6/WORLD_SCALE)  ,  new b2d.b2Vec2(118/WORLD_SCALE, 6/WORLD_SCALE)  ],
												 [   new b2d.b2Vec2(184/WORLD_SCALE, 0/WORLD_SCALE)  ,  new b2d.b2Vec2(224/WORLD_SCALE, 0/WORLD_SCALE)  ,  new b2d.b2Vec2(183/WORLD_SCALE, 30/WORLD_SCALE)  ]
											]};			
	
	var b2dL2shape3={"POLYGON":
		[

													[   new b2d.b2Vec2(2/WORLD_SCALE, 62/WORLD_SCALE)  ,  new b2d.b2Vec2(0/WORLD_SCALE, 0/WORLD_SCALE)  ,  new b2d.b2Vec2(31/WORLD_SCALE, 31.5/WORLD_SCALE)  ,  new b2d.b2Vec2(31/WORLD_SCALE, 61/WORLD_SCALE)  ] ,
													[   new b2d.b2Vec2(31/WORLD_SCALE, 31.5/WORLD_SCALE)  ,  new b2d.b2Vec2(0/WORLD_SCALE, 0/WORLD_SCALE)  ,  new b2d.b2Vec2(98/WORLD_SCALE, 0/WORLD_SCALE)  ,  new b2d.b2Vec2(98/WORLD_SCALE, 32/WORLD_SCALE)  ]
												]}
	*/										
	function createDRectangeleBody(sprite,w,h,name,world)
	{
		
			var bodyDef;
			var fixDef = new b2d.b2FixtureDef();
			fixDef.isSensor  =true;
			fixDef.userData=name;
			fixDef.shape = new b2d.b2PolygonShape();
			fixDef.shape.SetAsOrientedBox((w)/WORLD_SCALE, (h)/WORLD_SCALE,new b2d.b2Vec2(0.0,0.0),0);
	
			bodyDef = new b2d.b2BodyDef();
			bodyDef.userData=sprite;
			bodyDef.type = sprite.D;
			bodyDef.position.Set((sprite.x)/WORLD_SCALE,sprite.y/WORLD_SCALE);
			var spritephysicsBody=world.CreateBody(bodyDef);
			spritephysicsBody.SetAngle(sprite.angle/(Math.PI*180))	
			spritephysicsBody.CreateFixture(fixDef);
			sprite.physicsBody=spritephysicsBody;
			
		
	}
												
	//add a physics rectangle
	function createRectangeleBody(sprite/*instance of cloneNode*/,w/*width of sprite*/,h/*height of sprite*/,name/*name of new b2d.b2FixtureDef()*/,world/*box2d world*/)
	{
		
			var bodyDef;
			//adding fixture defination
			var fixDef = new b2d.b2FixtureDef();
			for (var fixkey in sprite.physicsAttributes["b2FixtureDef"]) {
					
					fixDef[fixkey]=sprite.physicsAttributes["b2FixtureDef"][fixkey];
				}
			fixDef.userData=name;
			fixDef.shape = new b2d.b2PolygonShape();
			fixDef.shape.SetAsOrientedBox((w)/WORLD_SCALE, (h)/WORLD_SCALE,new b2d.b2Vec2(0.0,0.0),0);
			//adding body defination
			bodyDef = new b2d.b2BodyDef();
			for (var defkey in sprite.physicsAttributes["b2BodyDef"]) {
					if(typeof bodyDef[defkey] != "undefined" && bodyDef[defkey]!="userData")
					{
						bodyDef[defkey]=sprite.physicsAttributes["b2BodyDef"][defkey];
						
					}
					
				}
			bodyDef.userData=sprite;
			
			bodyDef.type = sprite.D;
			bodyDef.position.Set((sprite.x)/WORLD_SCALE,sprite.y/WORLD_SCALE);
			var spritephysicsBody=world.CreateBody(bodyDef);
			spritephysicsBody.SetAngle(sprite.angle/(Math.PI*180))	
			spritephysicsBody.CreateFixture(fixDef);
			sprite.physicsBody=spritephysicsBody;
	}
//add a physics circle
	function createCricleBody(sprite/*instance of cloneNode*/,radius/*radius of cricle*/,name/*name of new b2d.b2FixtureDef()*/,world)
	{
			var bodyDef;
			bodyDef = new b2d.b2BodyDef();
					for (var defkey in sprite.physicsAttributes["b2BodyDef"]) {
					if(typeof bodyDef[defkey] != "undefined" && bodyDef[defkey]!="userData")
					{
						bodyDef[defkey]=sprite.physicsAttributes["b2BodyDef"][defkey];
						
					}
					
			}
			bodyDef.type = sprite.D;
			bodyDef.position.x = (sprite.x)/WORLD_SCALE;
			bodyDef.position.y =(sprite.y)/WORLD_SCALE;
			bodyDef.userData=sprite;
			
			var fixDef = new b2d.b2FixtureDef();
			for (var fixkey in sprite.physicsAttributes["b2FixtureDef"]) {
					
					fixDef[fixkey]=sprite.physicsAttributes["b2FixtureDef"][fixkey];
				}
			fixDef.userData=name;
			fixDef.shape = new b2d.b2CircleShape();
			fixDef.shape.SetRadius(radius/WORLD_SCALE);
			
			var spritephysicsBody=world.CreateBody(bodyDef);
	
			spritephysicsBody.CreateFixture(fixDef);
			
			sprite.physicsBody=spritephysicsBody;
	}
//add a polygon loop  for complex shape 
	function  createPolygonBody(sprite/*instance of cloneNode*/,ptype/*loop polygon type*/,name/*name of polygon*/,world)
	{
		
		
		if(ptype=="star")
		{
	
			createComplexBody(sprite,ptype,name,world);
		}
		else if(ptype=="L2shape3")
		{
			createComplexBody(sprite,ptype,name,world);
		}
		else if(ptype=="level34-5")
		{
			
			createComplexBody(sprite,ptype,name,world);
		}
		else if(ptype=="level34-5f")
		{
			
			createComplexBody(sprite,ptype,name,world);
		}
		else if(ptype=="7th1")
		{
			
			createComplexBody(sprite,ptype,name,world);
		}
	}
	//add  star to the world-------------------------------------------------------------------------//-----------------------------------------------------------------------------------------
	function createComplexBody(sprite,ptype,name,world)
	{
		switch(ptype)
			{
				case "star":
					var b2dstarPolygon={"POLYGON":

												// vertexes of decomposed polygons
												[

													[   new b2d.b2Vec2(93/WORLD_SCALE, 77/WORLD_SCALE)  ,  new b2d.b2Vec2(66/WORLD_SCALE, 96/WORLD_SCALE)  ,  new b2d.b2Vec2(40/WORLD_SCALE, 77/WORLD_SCALE)  ,  new b2d.b2Vec2(49/WORLD_SCALE, 45/WORLD_SCALE)  ,  new b2d.b2Vec2(82/WORLD_SCALE, 45/WORLD_SCALE)  ,  new b2d.b2Vec2(130/WORLD_SCALE, 47/WORLD_SCALE)  ] ,
													[   new b2d.b2Vec2(49/WORLD_SCALE, 45/WORLD_SCALE)  ,  new b2d.b2Vec2(40/WORLD_SCALE, 77/WORLD_SCALE)  ,  new b2d.b2Vec2(2/WORLD_SCALE, 47/WORLD_SCALE)  ] ,
													[   new b2d.b2Vec2(82/WORLD_SCALE, 45/WORLD_SCALE)  ,  new b2d.b2Vec2(49/WORLD_SCALE, 45/WORLD_SCALE)  ,  new b2d.b2Vec2(66/WORLD_SCALE, 0/WORLD_SCALE)  ] ,
													[   new b2d.b2Vec2(66/WORLD_SCALE, 96/WORLD_SCALE)  ,  new b2d.b2Vec2(93/WORLD_SCALE, 77/WORLD_SCALE)  ,  new b2d.b2Vec2(107/WORLD_SCALE, 123/WORLD_SCALE)  ] ,
													[   new b2d.b2Vec2(40/WORLD_SCALE, 77/WORLD_SCALE)  ,  new b2d.b2Vec2(66/WORLD_SCALE, 96/WORLD_SCALE)  ,  new b2d.b2Vec2(26/WORLD_SCALE, 125/WORLD_SCALE)  ]
												]};
					b2dPoly=b2dstarPolygon;
					break;
					
				case "L2shape3":

						
					
					var b2dlevel345={"POLYGON":
					[

													[   new b2d.b2Vec2(2/WORLD_SCALE, 62/WORLD_SCALE)  ,  new b2d.b2Vec2(0/WORLD_SCALE, 0/WORLD_SCALE)  ,  new b2d.b2Vec2(31/WORLD_SCALE, 31.5/WORLD_SCALE)  ,  new b2d.b2Vec2(31/WORLD_SCALE, 61/WORLD_SCALE)  ] ,
													[   new b2d.b2Vec2(31/WORLD_SCALE, 31.5/WORLD_SCALE)  ,  new b2d.b2Vec2(0/WORLD_SCALE, 0/WORLD_SCALE)  ,  new b2d.b2Vec2(98/WORLD_SCALE, 0/WORLD_SCALE)  ,  new b2d.b2Vec2(98/WORLD_SCALE, 32/WORLD_SCALE)  ]
												]}
												
					b2dPoly=b2dlevel345;
					break;
					
			case "level34-5":

						
					
					var b2dlevel345={"POLYGON":
					[
											 [   new b2d.b2Vec2(2/WORLD_SCALE, 31/WORLD_SCALE)  ,  new b2d.b2Vec2(1/WORLD_SCALE, 4/WORLD_SCALE)  ,  new b2d.b2Vec2(36/WORLD_SCALE, 4/WORLD_SCALE)  ],
											 [   new b2d.b2Vec2(105/WORLD_SCALE, 30/WORLD_SCALE)  ,  new b2d.b2Vec2(105/WORLD_SCALE, 4/WORLD_SCALE)  ,  new b2d.b2Vec2(216/WORLD_SCALE, 4/WORLD_SCALE)  ]
                                            
											]};
												
					b2dPoly=b2dlevel345;
					break;
					
					
			case "level34-5f":

						
					

					var b2dlevel345F={"POLYGON":
		    

                                              [
												 [   new b2d.b2Vec2(6/WORLD_SCALE, 33/WORLD_SCALE)  ,  new b2d.b2Vec2(5/WORLD_SCALE, 6/WORLD_SCALE)  ,  new b2d.b2Vec2(118/WORLD_SCALE, 6/WORLD_SCALE)  ],
												 [   new b2d.b2Vec2(184/WORLD_SCALE, 0/WORLD_SCALE)  ,  new b2d.b2Vec2(224/WORLD_SCALE, 0/WORLD_SCALE)  ,  new b2d.b2Vec2(183/WORLD_SCALE, 30/WORLD_SCALE)  ]
											]};	
											
					b2dPoly=b2dlevel345F;
					break;
					
			case "7th1":

						
					

					var b2d7th1={"POLYGON":
		    
											 [

                                                [   new b2d.b2Vec2(83.5/WORLD_SCALE, 0/WORLD_SCALE)  ,  new b2d.b2Vec2(168.5/WORLD_SCALE, 146/WORLD_SCALE)  ,  new b2d.b2Vec2(0/WORLD_SCALE, 145.5/WORLD_SCALE)  ]
											]
                                             };	
											
					b2dPoly=b2d7th1;
					break;

		}
												
												
												
		var fixDef = new b2d.b2FixtureDef();
		for (var fixkey in sprite.physicsAttributes["b2FixtureDef"])
		{
			fixDef[fixkey]=sprite.physicsAttributes["b2FixtureDef"][fixkey];
		}
		fixDef.userData=name;							
		var bodyDef = new b2d.b2BodyDef();
		for (var defkey in sprite.physicsAttributes["b2BodyDef"]) {
				if(typeof bodyDef[defkey] != "undefined" && bodyDef[defkey]!="userData")
				{
					bodyDef[defkey]=sprite.physicsAttributes["b2BodyDef"][defkey];
				}
					
			}
		bodyDef.type = sprite.D;
		bodyDef.position.x = sprite.x/WORLD_SCALE;
		bodyDef.position.y = sprite.y/WORLD_SCALE;
		bodyDef.userData=sprite;
		var BODY=world.CreateBody(bodyDef);
		BODY.GetWorldCenter()
		fixDef.shape = new b2d.b2PolygonShape();
		for(var  j=0;j<b2dPoly["POLYGON"].length;j++)
		{
     		var points=[];
		    for (var i = 0; i <b2dPoly["POLYGON"][j].length; i++) {
				var vec=b2dPoly["POLYGON"][j][i];
				vec.Set(vec.x-(sprite.image.width/2/WORLD_SCALE), vec.y-(sprite.image.height/2/WORLD_SCALE));
				points[i] = vec;
					
			}
			fixDef.shape.SetAsArray(points, points.length); 
		
			BODY.CreateFixture(fixDef);
			
		}		
		BODY.SetAngle(sprite.angle/(Math.PI*180))	
		sprite.physicsBody=BODY;	
		
	}
