
(function() {

function Preloader(data, reference) {
	
	this.Container_constructor();
	this.data = data;
	
	totalItems=this.data.length;
	this.reference=reference;
	this.setup();
	this.init();
}
var p = createjs.extend(Preloader, createjs.Container);

//global variables
var loadBar;
var percentage=0;
var loader;
var progress;

p.init=function()
{
	
	progress = new createjs.Shape(); 
    progress.graphics.beginStroke("#Cff").drawRect(0,0, 200, 20);
	progress.x=400;
	progress.y=400;
	this.addChild(progress); 
	
	loader = new createjs.LoadQueue(false);
	loader.main=this.reference;
	loader.root=this;
    loader.addEventListener("progress", handleProgress,false);
    loader.addEventListener("complete", handleComplete,false);
    loader.addEventListener("fileload", handleFileLoad,false);
	loader.loadManifest(this.data);
  


	
}
p.updateLoaderGraphics=function(total,loaded)
{

  
    progress.graphics.clear();
	progress.graphics.beginStroke("#Cff").drawRect(0,0,total*200,20);
    progress.graphics.beginFill("#C33").drawRect(0,0,loaded*200,20);
    
	
}
p.removeGraphics=function()
{
	console.log(this.reference);
	loader.removeAllEventListeners();
	loader=null;
	progress.graphics.clear();
	this.removeChild(progress);
	this.reference.allLoadingDone();
}
//preload functions responsible for loading of all graphics and sound
function handleProgress(event)
{
	
	 
	loader.root.updateLoaderGraphics(event.total,event.loaded);
	
}
function handleComplete(event) {
   loader.root.removeGraphics();
	
}
function handleLoadComplete(event) 
{
	
	//console.log(event.target.width);
}

function handleFileLoad(event) {
		//console.log(event.item.id);
  switch(event.item.type)
  {
	 
	  case createjs.LoadQueue.IMAGE:
	 
	  	if(event.item.id=="button")
		{
				
				var img = new Image();
	   			img.src =  event.item.src;
     			img.onload = handleLoadComplete;
	
				var spriteSheet = new createjs.SpriteSheet({
				framerate: 12,
				"images": [img],
				"frames": {"regX": 56.8, "height": 39, "count": 3, "regY": 19.5, "width": 113.6},
				"animations": {
					"none": [0, 0, "none"],
					"rollOver": [0, 1, "rollOver"]
				   }
			    });
			   window[event.item.id]= new createjs.Sprite(spriteSheet, "none");	
		}
		else	if(event.item.id=="te1In")
		{
				
				var img = new Image();
	   			img.src =  event.item.src;
     			img.onload = handleLoadComplete;
				
				var spriteSheet = new createjs.SpriteSheet({
				framerate: 60,
				"images": [img],
				"frames": {"regX": 85.33, "height": 85.36, "count": 132, "regY": 42.68, "width": 170.66},
				"animations": {
					"walk": [0, 131, "walk",1],
				   }
			    });
			   window[event.item.id]= new createjs.Sprite(spriteSheet, "walk");	
		}
		else	if(event.item.id=="walking")
		{
				
				var img = new Image();
	   			img.src =  event.item.src;
     			img.onload = handleLoadComplete;
				console.log(img);
				var spriteSheet = new createjs.SpriteSheet({
				framerate: 12,
				"images": [img],
				"frames": {"regX": 24, "height": 62, "count":72, "regY": 31, "width":48},
				"animations": {
					"walk": [0, 0, "walk"],
				   }
			    });
			   window[event.item.id]= new createjs.Sprite(spriteSheet, "walk");	
		}
		else	if(event.item.id=="man")
		{
			
				var img = new Image();
	   			img.src =  event.item.src;
     			img.onload = handleLoadComplete;
				console.log(img);
				var spriteSheet = new createjs.SpriteSheet({
				framerate: 12,
				"images": [img],
				"frames": {"regX": 162.5, "height": 220.5, "count": 8, "regY": 82.75, "width":110.25},
				"animations": {
					"walk": [0, 7, "walk"],
					}
			    });
			   window[event.item.id]= new createjs.Sprite(spriteSheet, "walk");	
			
		}
		else	if(event.item.id=="fly")
		{
			
				var img = new Image();
	   			img.src =  event.item.src;
     			img.onload = handleLoadComplete;
				console.log(img);
				var spriteSheet = new createjs.SpriteSheet({
				framerate: 12,
				"images": [img],
				"frames": {"regX":100, "height": 169, "count": 56, "regY":169/2, "width":200},
				"animations": {
					"fly": [0, 55, "fly"],
					}
			    });
			   window[event.item.id]= new createjs.Sprite(spriteSheet, "fly");	
			
		}
		else
		{
	  		   var img = new Image();
   		       img.src =  event.item.src;
    		   img.onload = handleLoadComplete;
    		   window[event.item.id] = new createjs.Bitmap(img);
		}
		break;
  }
}



p.setup = function() {
	/*
	all setup is here
	*/
	createjs.Ticker.setFPS();
	createjs.Ticker.useRAF = true;
	createjs.Ticker.addEventListener("tick", this.update);
	

	var background = new createjs.Shape();
	background.graphics.beginFill("#FFF").drawRoundRect(0,0,1000,625,0);
	this.addChild(background); 
	
	

		
} ;

//update on every frame
p.update=function(event)
{
	

}
//stop update on every frame
p.stopUpdate=function()
{
	createjs.Ticker.removeEventListener("tick", this.update);
}
//set name get name not required can be added at the run time
p.setName=function(_name)
{
	this.name=_name;
}
p.getName=function(_name)
{
	return this.name;
}



window.Preloader = createjs.promote(Preloader, "Container");
}());