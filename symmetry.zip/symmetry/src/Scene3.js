 //for local loading 

(function() {
	//debug canvas
	//var debugCanvas;
	//parent of scene class----------------------------------------------------------------------------------------------------------------------------------------
	var parent;
	//stage Reference----------------------------------------------------------------------------------------------------------------------------------------
	//drawing stage
	var stage;
	//private variable 
	//storing physics world
	var world;
	var init;
	function Scene3(){}

				Scene3.init = function(__stage,__parent){
				stage=__stage;
				parent=__parent;
				init = new Scene3();
				//all drawing for level1
				draw();
		
		}
		//draw background
		function draw()
		{
				stage.mouseChildren=false;
				//adding background to the game
				var gameBg=bg.clone();
				stage.addChild(gameBg);
				stage.update();
				//addChild physics delegate and contact listener
				setupPhysics();
		}
		function setupPhysics()
		{	
				//adding default physics world
				addDefaultPhysicsWorld();
				//fill physics world with box circles and complex shapes
				fillPhysicsWorld();
				var localcontact=new b2d.ContactListener;
				world.SetContactListener( localcontact);
				//contact delegate
				localcontact.BeginContact = function(contact) {

					var b2WorldManifold= new b2d.Manifold();
					contact.GetWorldManifold(b2WorldManifold)
				
						if(contact.GetFixtureA().GetBody().m_userData==null || contact.GetFixtureB().GetBody().m_userData==null)
						{
							return;
						}
						if((contact.GetFixtureB().m_userData==contact.GetFixtureA().GetBody().m_userData.interaction) && (contact.GetFixtureA().m_userData==contact.GetFixtureB().GetBody().m_userData.interaction ))
						{
							stage.removeChild(contact.GetFixtureA().GetBody().m_userData);
							collideBodies+=1;
							if(totalcollideBodies==collideBodies)
							{
								AllbodiesCollide=true;
							}
						}
								
				};
				createjs.Ticker.setFPS(60);
				createjs.Ticker.addEventListener("tick", update);
		}
		//fill physics world
		function fillPhysicsWorld()
		{
				//var Level="level"+currentLevel;
				var type;
				var widthtoSlice;
				var heighttoSlice;
				var action;
				
				var levelData=gameData["gameData"]["level"][currentLevel-1]["object"];
			
				for(i=0;i<levelData.length;i++)
				{
					var object = window[levelData[i]["img"]];
					var sprite=object.clone();
					sprite.regX=sprite.image.width/2;
					sprite.regY=(sprite.image.height)/2;
					var D=eval(levelData[i]["bodyType"]);
					

					
					sprite.physicsAttributes=gameData["gameData"]["physics"][levelData[i]["physics"]];
					sprite.D=D;
					sprite.angle=levelData[i]["rotation"];
					if(levelData[i]["scaleX"]==-1)
					{
						sprite.scaleX=-1;
					}
					sprite.name=levelData[i]["m_userData"];
					sprite.isContact=levelData[i]["contact"];
					sprite.x=levelData[i]["position"]["x"]+levelData[i]["margin"]["x"];
					sprite.y=levelData[i]["position"]["y"]+levelData[i]["margin"]["y"];
					stage.addChild(sprite);
				
					widthtoSlice=levelData[i]["sliceSize"]["width"];
					heighttoSlice=levelData[i]["sliceSize"]["height"];
					type=levelData[i]["type"];
					sprite.interaction=levelData[i]["interaction"];
					action=levelData[i]["action"];
					var polygonType=levelData[i]["polytype"];
					switch(type)
					{
						case "box":
						createRectangeleBody(sprite,((sprite.image.width/2)+heighttoSlice),((sprite.image.height/2)+heighttoSlice),levelData[i]["m_userData"],world);
						break;
						
									
						case "circle":
						createCricleBody(sprite,levelData[i]["radius"],levelData[i]["m_userData"],world);
						break;
						
						
						case "polygon":
						createPolygonBody(sprite,polygonType,levelData[i]["m_userData"],world);
						break;
						
						case "Dbox":
						totalcollideBodies+=1;
						sprite.alpha=levelData[i]["alpha"];
						createDRectangeleBody(sprite,((sprite.image.width/2)+heighttoSlice),((sprite.image.height/2)+heighttoSlice),levelData[i]["m_userData"],world);
						break;
					}
					
					//checking click action
					if(action=="click")
					{
							numberOfbodies++;
							sprite.addEventListener("click", removeBodyandSprite);
					}
				} 
				stage.alpha=0;
				var stageAlpha= createjs.Tween.get(stage)
				.to({alpha:1, visible:false}, 1000)
				.call(readyForPlay);
		}
		
		function removeBodyandSprite(evt)
		{

					bodiesDistroyed+=1;
					if(numberOfbodies==bodiesDistroyed)
					{
						AllbodiesDistroyed=true;
			
					}
					world.DestroyBody(evt.target.physicsBody);
					stage.removeChild(evt.target);
		}
		function readyForPlay()
		{
				stage.mouseChildren=true;
				addLocalButtons();
		}
		
		function addLocalButtons()
		{
				var resetButton = new Button("Reset", "#F00",this,button.clone());
				stage.addChild(resetButton);
				resetButton.x=800;
				resetButton.y=610;
				resetButton.on("click", parent.gotoandPlayLevel);
		}
		//update loop for the game
		function update(event)
		{
				//physics debug drawing added from here========================================== 
				world.DrawDebugData();
				world.Step(1/60, 10,10);
				for (var body = world.GetBodyList(); body; body = body.GetNext()) {
					if (body.GetUserData()) 
					{  
						object=body.GetUserData();
						object.x=body.GetPosition().x*WORLD_SCALE;
						object.y=body.GetPosition().y*WORLD_SCALE;
						object.rotation = body.GetAngle()/Math.PI*180;
						
					}
				}
				//remove body from box2d if required================================================
				if(bodies.length>0)
				{
					for(var i=0;i<bodies.length;i++)
					{
					  //world.DestroyBody(bodies[i]);
					  // bodies.splice(i, 1);
					}
				}
				
				if(AllbodiesCollide && AllbodiesDistroyed && !levelCleared)
				{
					 movetoNextLevel();
					 levelCleared=true;
				}
			
				stage.update();
		}
		//moveBy to Next level
		function movetoNextLevel()
		{
				var time=500;
				var nextLevel = new Button("Next Level", "#F00",this,button.clone());
				stage.addChild(nextLevel);
				nextLevel.x=200;
				nextLevel.y=910;
				nextLevel.on("click", gotonextLevel);
				var t=createjs.Tween.get(nextLevel)
					 .wait(time)
					 .to({y:610}, 1000)
					 .call(showNextButton);
		
		}
		function gotonextLevel()
		{
			parent.updateLevel();
			parent.gotoandPlayLevel();
		}
		function showNextButton()
		{
		
			    stage.mouseChildren=true;
		}
		//adding default physics world
		function addDefaultPhysicsWorld()
		{
				var w = stage.canvas.width;
				var h = stage.canvas.height;
				world = new b2d.b2World(new b2d.b2Vec2(0, 20), true);
				//add with debugger
				var debugDraw = new b2d.b2DebugDraw();
				debugDraw.SetSprite(debugCanvas.getContext("2d"));
				debugDraw.SetDrawScale( WORLD_SCALE);
				debugDraw.SetFillAlpha(0.5);
				debugDraw.SetLineThickness(1);
				debugDraw.SetFlags(b2d.b2DebugDraw.e_shapeBit | b2d.b2DebugDraw.e_jointBit);
				world.SetDebugDraw(debugDraw);
				
				//add ground defination 
				GroundLayer(w,h);
		}
		//constant groud layer for every level1
		function GroundLayer(w,h)
		{
				var fixDef = new b2d.b2FixtureDef();
				fixDef.density = 1;
				fixDef.friction = 0.5;
				fixDef.restitution = 0;
				fixDef.shape = new b2d.b2PolygonShape();
				fixDef.shape.SetAsBox(w/WORLD_SCALE*0.6, 10/WORLD_SCALE);
				var bodyDef = new b2d.b2BodyDef();
				bodyDef.type = b2d.b2Body.b2_staticBody;
				bodyDef.position.x = (w+100)/2/WORLD_SCALE;
				bodyDef.position.y = 575.5/WORLD_SCALE;
				world.CreateBody(bodyDef).CreateFixture(fixDef);
				stage.update();
				console.log(debugCanvas.getContext("2d"));
		}
		
		
		
	window.Scene3 = Scene3;	
})();