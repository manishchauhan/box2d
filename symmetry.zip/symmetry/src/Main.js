
	
// JavaScript Document
(function(){
	/*add box2d variables
	*/
	// JavaScript Document
	//checking number of bodies left
	var numberOfbodies=0;
	var bodiesDistroyed=0;
	var collideBodies=0;
	var totalcollideBodies=0;
	var AllbodiesDistroyed=false;
	var AllbodiesCollide=false;
	var levelCleared=false;
	
	var bodies=[];
	var b2d = {
		b2Vec2 : Box2D.Common.Math.b2Vec2,
		b2BodyDef : Box2D.Dynamics.b2BodyDef,
		b2Body : Box2D.Dynamics.b2Body,
		b2FixtureDef : Box2D.Dynamics.b2FixtureDef,
		b2Fixture : Box2D.Dynamics.b2Fixture,
		b2World : Box2D.Dynamics.b2World,
		b2MassData : Box2D.Collision.Shapes.b2MassData,
		b2PolygonShape : Box2D.Collision.Shapes.b2PolygonShape,
		b2CircleShape : Box2D.Collision.Shapes.b2CircleShape,
		b2DebugDraw : Box2D.Dynamics.b2DebugDraw,
		ContactListener : Box2D.Dynamics.b2ContactListener,
		Manifold: Box2D.Collision.b2WorldManifold
	};
	var world;
	var WORLD_SCALE=32.0;
	var gameBg;
	var Level=2;
	var limitX=0;
	var userAnswer=[];
	var Answer=[];
	var destinationGot=false;

	/*

		 local game variables
		 ========================================================================================================================================================================
	*/
	var gameData="loaded";
	var canvas;
	var debugCanvas;
	var main;
	var loader;
	/*

		 class function  
		 ========================================================================================================================================================================
	*/
	function Main(){}

	Main.main = function(){
		main = new Main();
		main.addAllcanvas();
		main.addGameStage();
	}
	Main.prototype.addAllcanvas=function()
	{
		//add game canvas
		canvas=document.createElement('canvas');
		canvas.setAttribute('style', 'position: fixed; top: 0px; left:0px;');
		canvas.width=1000;
		canvas.height=625;
		document.body.appendChild(canvas);
		//add debug canvas
		addDebuglayer();
		
	}
	function addDebuglayer()
	{
		debugCanvas = document.createElement('canvas');
		debugCanvas.setAttribute('style', 'position: fixed; top: 0px; left:0px;');
		debugCanvas.width=1000;
		debugCanvas.height=625;
		document.body.appendChild(debugCanvas);
	}
	//
	Main.prototype.showPhysics=function(status)
	{
		if(status && debugCanvas)
		{
				document.body.appendChild(debugCanvas);
		}
		else if(!status && debugCanvas)
		{
				document.body.removeChild(debugCanvas);
				debugCanvas=null;
		}
	}
	//adding game stage
	Main.prototype.addGameStage=function()
	{
		stage = new createjs.Stage(canvas);
		stage.autoClear = true;
		stage.snapToPixelsEnabled=true;
		stage.enableMouseOver();
		stage.enableDOMEvents(true);
		createjs.Touch.enable(stage);
		stage.mouseChildren=false;
		//load json
		loadJson();

	}
	function loadJson()
	{
		var queue = new createjs.LoadQueue(true);
		queue.loadManifest({src:"bin/dataSource/json/gameData.json", type: "manifest"});
		queue.on("fileload", handlejsonFileLoad, this);
		queue.on("complete", handlejsonComplete, this);
	}
	function handlejsonFileLoad(evt)
	{
		
		gameData=evt.result;
		LoadGraphicsAndSounds();
	}
	function handlejsonComplete(evt)
	{
	   
	}
	function LoadGraphicsAndSounds()
	{		
		loader =new Preloader(gameData["gameData"]["manifest"], main)
		loader.x=0;
		loader.y=0;
		stage.addChild(loader);
		updateStage();
	}
	Main.prototype.allLoadingDone=function()
	{
		//console.log(gameData["gameData"]["manifest"]);
		updateStage();
		addInstructionScreen();
	}
	function updateStage()
	{
		stage.update();
		
	}
	//add addInstructionScreen
	function addInstructionScreen()
	{
			
			
		gameBg=bg.clone();
		stage.addChild(gameBg);
		updateStage();
		addBox2d();
		//by default frame rate is 60 frame per second
		createjs.Ticker.setFPS(60);
	}
	Main.prototype.resetLevel=function(evt)
	{
		userAnswer=[];
		Answer=[];
		destinationGot=false;
		numberOfbodies=0;
		bodiesDistroyed=0;
		collideBodies=0;
		totalcollideBodies=0;
		AllbodiesDistroyed=false;
		AllbodiesCollide=false;
		levelCleared=false;
		var time=0;
		//clear all objects and  tick events---------------------------
		stage.removeAllChildren();
		clearPhysics();
		switch(Level)
		{
			case 1:
			createjs.Ticker.removeEventListener("tick", updateLevel1);
			break;
			case 2:
			createjs.Ticker.removeEventListener("tick", updateLevel2);
			break;
			case 3:
			createjs.Ticker.removeEventListener("tick", updateLevel3);
			break;
		}
		//clear all objects and  tick events---------------------------
		addDebuglayer();
		gameBg=bg.clone();
		stage.addChild(gameBg);
		switch(Level)
		{
			case 1:
			setupPhysicsLevel1();
			break;
			case 2:
			setupPhysicsLevel2();
			break;
			case 3:
			setupPhysicsLevel3();
			break;
		}
	}
	function clearPhysics()
	{
		
		for (var body = world.GetBodyList(); body; body = body.GetNext()) 
		{
			 world.DestroyBody(body);
		}
		world=null;
	}
	//add box2d for the game
	function addBox2d()
	{
		switch(Level)
		{
			case 1:
			setupPhysicsLevel1();
			break;
			case 2:
			setupPhysicsLevel2();
			break;
			case 3:
			setupPhysicsLevel3();
			break;
		}
		
		
	}

	//********************************************LEVEL ONE START FROM HERE*********************************************************************************************************        
	function setupPhysicsLevel1()
	{
		
		addDefaultPhysicsWorld();
		main.showPhysics(false);
		addLevel1();
		
		var localcontact=new b2d.ContactListener;
		world.SetContactListener( localcontact);
		localcontact.BeginContact = function(contact) {
			
				if(contact.GetFixtureA().GetBody().m_userData==null || contact.GetFixtureB().GetBody().m_userData==null)
					{
						return;
					}
				if((contact.GetFixtureB().m_userData==contact.GetFixtureA().GetBody().m_userData.interaction) && (contact.GetFixtureA().m_userData==contact.GetFixtureB().GetBody().m_userData.interaction ))
					{
						
						stage.removeChild(contact.GetFixtureB().GetBody().m_userData);
						collideBodies+=1;
						if(totalcollideBodies==collideBodies)
						{
							AllbodiesCollide=true;
						}
				}

		};
		createjs.Ticker.addEventListener("tick", updateLevel1);
	}
	function addLevel1()
	{

		
		var currentLevel="level"+Level;
		var type;
		var widthtoSlice;
		var heighttoSlice;
		var action;
		limitX=24.0;
		for(i=0;i<gameData["levelData"][currentLevel].length;i++)
		{
			var object = window[gameData["levelData"][currentLevel][i]["img"]];
			var sprite=object.clone();
			sprite.regX=sprite.image.width/2;
			sprite.regY=(sprite.image.height)/2;
			var D=eval(gameData["levelData"][currentLevel][i]["bodyType"]);
			sprite.physicsAttributes=gameData["physics"][gameData["levelData"][currentLevel][i]["physics"]];
			sprite.D=D;
			sprite.angle=gameData["levelData"][currentLevel][i]["rotation"];
			sprite.name=gameData["levelData"][currentLevel][i]["m_userData"];
			sprite.isContact=gameData["levelData"][currentLevel][i]["contact"];
			sprite.x=gameData["levelData"][currentLevel][i]["position"]["x"]+gameData["levelData"][currentLevel][i]["margin"]["x"];
			sprite.y=gameData["levelData"][currentLevel][i]["position"]["y"]+gameData["levelData"][currentLevel][i]["margin"]["y"];
			stage.addChild(sprite);
		
			widthtoSlice=gameData["levelData"][currentLevel][i]["sliceSize"]["width"];
			heighttoSlice=gameData["levelData"][currentLevel][i]["sliceSize"]["height"];
			type=gameData["levelData"][currentLevel][i]["type"];
			sprite.interaction=gameData["levelData"][currentLevel][i]["interaction"];
			action=gameData["levelData"][currentLevel][i]["action"];
			var polygonType=gameData["levelData"][currentLevel][i]["polytype"];
			if(type=="box")
			{

			  createRectangeleBody(sprite,((sprite.image.width/2)+heighttoSlice),((sprite.image.height/2)+heighttoSlice),gameData["levelData"][currentLevel][i]["m_userData"]);
			}
			else if(type=="Dbox")
			{
				
				totalcollideBodies+=1;
				sprite.alpha=gameData["levelData"][currentLevel][i]["alpha"];
				createDRectangeleBody(sprite,((sprite.image.width/2)+heighttoSlice),((sprite.image.height/2)+heighttoSlice),gameData["levelData"][currentLevel][i]["m_userData"]);
			}
			else if(type=="polygon")
			{
				createPolygonBody(sprite,polygonType,gameData["levelData"][currentLevel][i]["m_userData"]);
			}
			if(action=="click")
			{
				numberOfbodies++;
					sprite.addEventListener("click", deleteShape);
			}
			//	console.log(AllbodiesCollide);

		}
		stage.alpha=0;
		var stageAlpha= createjs.Tween.get(stage)
			 .to({alpha:1, visible:false}, 1000)
			 .call(handleCompleteLevel1);
			//updateStage();
	}
	function handleCompleteLevel1(evt)
	{
		stage.mouseChildren=true;
		addMenuButtons();
	}

	function addMenuButtons()
	{
		var resetLevelButton = new Button("Reset", "#F00",this,button.clone());
		stage.addChild(resetLevelButton);
		resetLevelButton.x=800;
		resetLevelButton.y=610;
		//resetLevelButton.on("click", main.resetLevel);
			

	}
	function deleteShape(evt)
	{

		bodiesDistroyed+=1;
		if(numberOfbodies==bodiesDistroyed)
		{
			AllbodiesDistroyed=true;
			
		}
		world.DestroyBody(evt.target.physicsBody);
		stage.removeChild(evt.target);
	}
	function updateLevel1(event)
	{
		//physics debug drawing added from here========================================== 
		world.DrawDebugData();
		world.Step(1/60, 10,10);
		for (var body = world.GetBodyList(); body; body = body.GetNext()) {
			if (body.GetUserData()) 
			{  
				object=body.GetUserData();
				object.x=body.GetPosition().x*WORLD_SCALE;
				object.y=body.GetPosition().y*WORLD_SCALE;
				object.rotation = body.GetAngle()/Math.PI*180;
				
			}
		}
		//remove body from box2d if required================================================
		if(bodies.length>0)
		{
			for(var i=0;i<bodies.length;i++)
			{
			  //world.DestroyBody(bodies[i]);
			  // bodies.splice(i, 1);
			}
		}
		
		if(AllbodiesCollide && AllbodiesDistroyed && !levelCleared)
		{
			 movetoNextLevel();
			levelCleared=true;
		}
	
		stage.update();
		
	}
	//********************************************LEVEL TWO START FROM HERE*********************************************************************************************************


	function setupPhysicsLevel2()
	{
		
		addDefaultPhysicsWorld();
		main.showPhysics(false);
		addLevel2();
		
		var localcontact=new b2d.ContactListener;
		world.SetContactListener( localcontact);
		localcontact.BeginContact = function(contact) {
		var b2WorldManifold= new b2d.Manifold();
		contact.GetWorldManifold(b2WorldManifold)
				if(contact.GetFixtureA().GetBody().m_userData==null || contact.GetFixtureB().GetBody().m_userData==null)
					{
						return;
					}
					if((contact.GetFixtureB().m_userData==contact.GetFixtureA().GetBody().m_userData.interaction) && (contact.GetFixtureA().m_userData==contact.GetFixtureB().GetBody().m_userData.interaction ))
					{
						stage.removeChild(contact.GetFixtureB().GetBody().m_userData);
						collideBodies+=1;
						if(totalcollideBodies==collideBodies)
						{
							AllbodiesCollide=true;
						}
					}

			};
		createjs.Ticker.addEventListener("tick", updateLevel2);
	}
	function updateLevel2(event)
	{
		//physics debug drawing added from here========================================== 
		world.DrawDebugData();
		world.Step(1/60, 10,10);
		for (var body = world.GetBodyList(); body; body = body.GetNext()) {
				if (body.GetUserData()) 
				{  
					  object=body.GetUserData();
						object.x=body.GetPosition().x*WORLD_SCALE;
						object.y=body.GetPosition().y*WORLD_SCALE;
					object.rotation = body.GetAngle()/Math.PI*180;
				
				
				
			}
		}
		//remove body from box2d if required================================================
		if(bodies.length>0)
		{
			for(var i=0;i<bodies.length;i++)
			{
			  //world.DestroyBody(bodies[i]);
			  // bodies.splice(i, 1);
			}
		}
	
		if(AllbodiesCollide && AllbodiesDistroyed && !levelCleared)
		{
			movetoNextLevel();
			levelCleared=true;
		}
		stage.update();
		
	}

	function addLevel2()
	{
		var currentLevel="level"+Level;
		var type;
		var widthtoSlice;
		var heighttoSlice;
		var action;
		Answer=["shape2","shape1"];
		limitX=24.0;
		for(i=0;i<gameData["levelData"][currentLevel].length;i++)
		{
			var object = window[gameData["levelData"][currentLevel][i]["img"]];
			var sprite=object.clone();
			sprite.regX=sprite.image.width/2;
			sprite.regY=(sprite.image.height)/2;
			var D=eval(gameData["levelData"][currentLevel][i]["bodyType"]);
			
			sprite.D=D;
			sprite.physicsAttributes=gameData["physics"][gameData["levelData"][currentLevel][i]["physics"]];
			sprite.angle=gameData["levelData"][currentLevel][i]["rotation"];
			sprite.name=gameData["levelData"][currentLevel][i]["m_userData"];
			sprite.isContact=gameData["levelData"][currentLevel][i]["contact"];
			sprite.x=gameData["levelData"][currentLevel][i]["position"]["x"]+gameData["levelData"][currentLevel][i]["margin"]["x"];
			sprite.y=gameData["levelData"][currentLevel][i]["position"]["y"]+gameData["levelData"][currentLevel][i]["margin"]["y"];
			stage.addChild(sprite);
			widthtoSlice=gameData["levelData"][currentLevel][i]["sliceSize"]["width"];
			heighttoSlice=gameData["levelData"][currentLevel][i]["sliceSize"]["height"];
			type=gameData["levelData"][currentLevel][i]["type"];
			sprite.interaction=gameData["levelData"][currentLevel][i]["interaction"];
			action=gameData["levelData"][currentLevel][i]["action"];
			var polygonType=gameData["levelData"][currentLevel][i]["polytype"];
			//check all type of bodies
			if(type=="box")
			{
				createRectangeleBody(sprite,((sprite.image.width/2)+heighttoSlice),((sprite.image.height/2)+heighttoSlice),gameData["levelData"][currentLevel][i]["m_userData"]);
			}
			else if(type=="circle")
			{
				createCricleBody(sprite,gameData["levelData"][currentLevel][i]["radius"],gameData["levelData"][currentLevel][i]["m_userData"]);
			}
			else if(type=="polygon")
			{
				createPolygonBody(sprite,polygonType,gameData["levelData"][currentLevel][i]["m_userData"]);
			}
			else if(type=="Dbox")
			{
				
				totalcollideBodies+=1;
				sprite.alpha=gameData["levelData"][currentLevel][i]["alpha"];
				createDRectangeleBody(sprite,((sprite.image.width/2)+heighttoSlice),((sprite.image.height/2)+heighttoSlice),gameData["levelData"][currentLevel][i]["m_userData"]);
			}
			//add click event
			if(action=="click")
			{
				numberOfbodies++;
				sprite.addEventListener("click", checkLevel2);
			}
		}
		stage.alpha=0;
		var stageAlpha= createjs.Tween.get(stage)
			 .to({alpha:1, visible:false}, 1000)
			 .call(handleCompleteLevel2);
		

	}

	function handleCompleteLevel2(evt)
	{
		stage.mouseChildren=true;
		addMenuButtons();
	}



	function checkLevel2(evt)
	{

		bodiesDistroyed+=1;
		if(numberOfbodies==bodiesDistroyed)
		{
			AllbodiesDistroyed=true;
			
		}
		world.DestroyBody(evt.target.physicsBody);
		stage.removeChild(evt.target);
				

	}

	//********************************************LEVEL THREE START FROM HERE*********************************************************************************************************

	function setupPhysicsLevel3()
	{
		addDefaultPhysicsWorld();
		main.showPhysics(false);
		addLevel3();
		
		var localcontact=new b2d.ContactListener;
		world.SetContactListener( localcontact);
		localcontact.BeginContact = function(contact) {
		var b2WorldManifold= new b2d.Manifold();
		contact.GetWorldManifold(b2WorldManifold)
				
					if(contact.GetFixtureA().GetBody().m_userData==null || contact.GetFixtureB().GetBody().m_userData==null)
					{
						return;
					}
					if((contact.GetFixtureB().m_userData==contact.GetFixtureA().GetBody().m_userData.interaction) && (contact.GetFixtureA().m_userData==contact.GetFixtureB().GetBody().m_userData.interaction ))
					{
						stage.removeChild(contact.GetFixtureA().GetBody().m_userData);
						collideBodies+=1;
						if(totalcollideBodies==collideBodies)
						{
							AllbodiesCollide=true;
						}
					}
				
			};
		createjs.Ticker.addEventListener("tick", updateLevel3);
		
	}
	function updateLevel3(event)
	{
		
		//physics debug drawing added from here========================================== 
		world.DrawDebugData();
		world.Step(1/60, 10,10);
		 world.ClearForces();
		for (var body = world.GetBodyList(); body; body = body.GetNext()) {
			
				if (body.GetUserData()) 
				{  
					  object=body.GetUserData();
						object.x=body.GetPosition().x*WORLD_SCALE;
						object.y=body.GetPosition().y*WORLD_SCALE;
					   object.rotation = body.GetAngle()/Math.PI*180;
					
				
				
			}
		}
		//remove body from box2d if required================================================
		if(bodies.length>0)
		{
			for(var i=0;i<bodies.length;i++)
			{
			  //world.DestroyBody(bodies[i]);
			  // bodies.splice(i, 1);
			}
		}
	//console.log(levelCleared);
		if(AllbodiesCollide && AllbodiesDistroyed && !levelCleared)
		{
			console.log("no more level");
			levelCleared=true;
		}
	
		stage.update();
		
	}
	function addLevel3()
	{
		var currentLevel="level"+Level;
		var type;
		var widthtoSlice;
		var heighttoSlice;
		var action;
		//Answer=gameData["answers"][0][currentLevel];
		limitX=24.0;
		for(i=0;i<gameData["levelData"][currentLevel].length;i++)
		{
			var object = window[gameData["levelData"][currentLevel][i]["img"]];
			var sprite=object.clone();
			
			sprite.regX=sprite.image.width/2;
			sprite.regY=(sprite.image.height/2);
			
			
			
			var D=eval(gameData["levelData"][currentLevel][i]["bodyType"]);
			sprite.D=D;
			sprite.physicsAttributes=gameData["physics"][gameData["levelData"][currentLevel][i]["physics"]];
			sprite.angle=gameData["levelData"][currentLevel][i]["rotation"];
			if(gameData["levelData"][currentLevel][i]["scaleX"]==-1)
			{
				sprite.scaleX=-1;
			}
			
			sprite.b2BodyDef=gameData["levelData"][currentLevel][i]["b2BodyDef"];
			
			sprite.name=gameData["levelData"][currentLevel][i]["m_userData"];
			
			sprite.isContact=gameData["levelData"][currentLevel][i]["contact"];
			sprite.x=gameData["levelData"][currentLevel][i]["position"]["x"]+gameData["levelData"][currentLevel][i]["margin"]["x"];
			sprite.y=gameData["levelData"][currentLevel][i]["position"]["y"]+gameData["levelData"][currentLevel][i]["margin"]["y"];
			stage.addChild(sprite);
			
			widthtoSlice=gameData["levelData"][currentLevel][i]["sliceSize"]["width"];
			heighttoSlice=gameData["levelData"][currentLevel][i]["sliceSize"]["height"];
			type=gameData["levelData"][currentLevel][i]["type"];
			action=gameData["levelData"][currentLevel][i]["action"];
				sprite.interaction=gameData["levelData"][currentLevel][i]["interaction"];
		
			var polygonType=gameData["levelData"][currentLevel][i]["polytype"];
			
			if(type=="box")
			{
				createRectangeleBody(sprite,((sprite.image.width/2)+heighttoSlice),((sprite.image.height/2)+heighttoSlice),gameData["levelData"][currentLevel][i]["m_userData"]);
			}
			else if(type=="Dbox")
			{
				totalcollideBodies+=1;
				sprite.alpha=gameData["levelData"][currentLevel][i]["alpha"];
				createDRectangeleBody(sprite,((sprite.image.width/2)+heighttoSlice),((sprite.image.height/2)+heighttoSlice),gameData["levelData"][currentLevel][i]["m_userData"]);
			}
			else if(type=="circle")
			{
				createCricleBody(sprite,gameData["levelData"][currentLevel][i]["radius"],gameData["levelData"][currentLevel][i]["m_userData"]);
			}
			else if(type=="polygon")
			{
				createPolygonBody(sprite,polygonType,gameData["levelData"][currentLevel][i]["m_userData"]);
			}
			if(action=="click")
			{
				numberOfbodies++;
				sprite.addEventListener("click", checkLevel3);
			}
		}
		stage.alpha=0;
		var stageAlpha= createjs.Tween.get(stage)
			 .to({alpha:1, visible:false}, 1000)
			 .call(handleCompleteLevel3);
	}
	function handleCompleteLevel3(evt)
	{
		stage.mouseChildren=true;
		addMenuButtons();
	}
	function checkLevel3(evt)
	{
		
		bodiesDistroyed+=1;
		if(numberOfbodies==bodiesDistroyed)
		{
			AllbodiesDistroyed=true;
			
		}
		world.DestroyBody(evt.target.physicsBody);
		stage.removeChild(evt.target);
	}


	/*
	all levels=========================================================================================================================================ends here
	*/

	//global function comman for all level=========================================================================================================
	Array.prototype.compare = function(testArr) {
		if (this.length != testArr.length) return false;
		for (var i = 0; i < testArr.length; i++) {
			if (this[i].compare) { 
				if (!this[i].compare(testArr[i])) return false;
			}
			if (this[i] !== testArr[i]) return false;
		}
		return true;
	}


	function movetoNextLevel()
	{
	
		

		var time=0;
		switch(Level)
		{
			case 1:
			time=500;
			break;
			case 2:
			time=500;
			break;
		}
		var nextLevel = new Button("Next Level", "#F00",this,button.clone());
		stage.addChild(nextLevel);
		nextLevel.x=200;
		nextLevel.y=910;
		nextLevel.on("click", main.gotoNextLevel);
		
		var t=createjs.Tween.get(nextLevel)
			 .wait(time)
			 .to({y:610}, 1000)
			 .call(showNextButton);
		
	}
	Main.prototype.gotoNextLevel=function(evt)
	{
		levelCleared=false;
		numberOfbodies=0;
		bodiesDistroyed=0;
		collideBodies=0;
		totalcollideBodies=0;
		AllbodiesDistroyed=false;
		AllbodiesCollide=false;
		//clear all objects and  tick events---------------------------
		stage.removeAllChildren();
		
		clearPhysics();
		
		switch(Level)
		{
			case 1:
			createjs.Ticker.removeEventListener("tick", updateLevel1);
			break;
			case 2:
			createjs.Ticker.removeEventListener("tick", updateLevel2);
			break;
			
		}
			
		//clear all objects and  tick events---------------------------
		Level+=1;
		addDebuglayer();
		gameBg=bg.clone();
		stage.addChild(gameBg);
		updateStage();
		switch(Level)
		{
			case 1:
			setupPhysicsLevel1();
			break;
			case 2:
			setupPhysicsLevel2();
			break;
			case 3:
			setupPhysicsLevel3();
			break;
		}
		
	}


	function showNextButton()
	{
		
		stage.mouseChildren=true;
	}

	
	//create a physics body
	//**************add star**********************
	function createPolystar(sprite,name)
	{
		;
		var P={"POLYGON":

												// vertexes of decomposed polygons
												[

													[   new b2d.b2Vec2(93/WORLD_SCALE, 77/WORLD_SCALE)  ,  new b2d.b2Vec2(66/WORLD_SCALE, 96/WORLD_SCALE)  ,  new b2d.b2Vec2(40/WORLD_SCALE, 77/WORLD_SCALE)  ,  new b2d.b2Vec2(49/WORLD_SCALE, 45/WORLD_SCALE)  ,  new b2d.b2Vec2(82/WORLD_SCALE, 45/WORLD_SCALE)  ,  new b2d.b2Vec2(130/WORLD_SCALE, 47/WORLD_SCALE)  ] ,
													[   new b2d.b2Vec2(49/WORLD_SCALE, 45/WORLD_SCALE)  ,  new b2d.b2Vec2(40/WORLD_SCALE, 77/WORLD_SCALE)  ,  new b2d.b2Vec2(2/WORLD_SCALE, 47/WORLD_SCALE)  ] ,
													[   new b2d.b2Vec2(82/WORLD_SCALE, 45/WORLD_SCALE)  ,  new b2d.b2Vec2(49/WORLD_SCALE, 45/WORLD_SCALE)  ,  new b2d.b2Vec2(66/WORLD_SCALE, 0/WORLD_SCALE)  ] ,
													[   new b2d.b2Vec2(66/WORLD_SCALE, 96/WORLD_SCALE)  ,  new b2d.b2Vec2(93/WORLD_SCALE, 77/WORLD_SCALE)  ,  new b2d.b2Vec2(107/WORLD_SCALE, 123/WORLD_SCALE)  ] ,
													[   new b2d.b2Vec2(40/WORLD_SCALE, 77/WORLD_SCALE)  ,  new b2d.b2Vec2(66/WORLD_SCALE, 96/WORLD_SCALE)  ,  new b2d.b2Vec2(26/WORLD_SCALE, 125/WORLD_SCALE)  ]
												]}
				
		var fixDef = new b2d.b2FixtureDef();
		for (var fixkey in sprite.physicsAttributes["b2FixtureDef"])
		{
			fixDef[fixkey]=sprite.physicsAttributes["b2FixtureDef"][fixkey];
		}
		fixDef.userData=name;							
		var bodyDef = new b2d.b2BodyDef();
		for (var defkey in sprite.physicsAttributes["b2BodyDef"]) {
				if(typeof bodyDef[defkey] != "undefined" && bodyDef[defkey]!="userData")
				{
					bodyDef[defkey]=sprite.physicsAttributes["b2BodyDef"][defkey];
				}
					
			}
		bodyDef.type = sprite.D;
		bodyDef.position.x = sprite.x/WORLD_SCALE;
		bodyDef.position.y = sprite.y/WORLD_SCALE;
		bodyDef.userData=sprite;
		var BODY=world.CreateBody(bodyDef);
		BODY.GetWorldCenter()
		fixDef.shape = new b2d.b2PolygonShape();
		for(var  j=0;j<P["POLYGON"].length;j++)
		{
			
			var points=[];
		   for (var i = 0; i < P["POLYGON"][j].length; i++) {
				var vec=P["POLYGON"][j][i];
				vec.Set(vec.x-(sprite.image.width/2/WORLD_SCALE), vec.y-(sprite.image.height/2/WORLD_SCALE));
				points[i] = vec;
					
			}
			fixDef.shape.SetAsArray(points, points.length); 
		
			BODY.CreateFixture(fixDef);
			
		}				
		sprite.physicsBody=BODY;									
	}
	//**************level34-5**********************
	function level345(sprite,name)
	{
		var P={"POLYGON":
		[
											 [   new b2d.b2Vec2(2/WORLD_SCALE, 31/WORLD_SCALE)  ,  new b2d.b2Vec2(1/WORLD_SCALE, 4/WORLD_SCALE)  ,  new b2d.b2Vec2(36/WORLD_SCALE, 4/WORLD_SCALE)  ],
											 [   new b2d.b2Vec2(105/WORLD_SCALE, 30/WORLD_SCALE)  ,  new b2d.b2Vec2(105/WORLD_SCALE, 4/WORLD_SCALE)  ,  new b2d.b2Vec2(216/WORLD_SCALE, 4/WORLD_SCALE)  ]
                                              //  [   new b2d.b2Vec2(32/WORLD_SCALE, 4/WORLD_SCALE)  ,  new b2d.b2Vec2(32/WORLD_SCALE, 27/WORLD_SCALE)  ,  new b2d.b2Vec2(3/WORLD_SCALE, 30/WORLD_SCALE)  ,  new b2d.b2Vec2(3/WORLD_SCALE, 4/WORLD_SCALE)  ] ,
                                               // [   new b2d.b2Vec2(220/WORLD_SCALE, 30/WORLD_SCALE)  ,  new b2d.b2Vec2(102/WORLD_SCALE, 27/WORLD_SCALE)  ,  new b2d.b2Vec2(102/WORLD_SCALE, 4/WORLD_SCALE)  ,  new b2d.b2Vec2(220/WORLD_SCALE, 4/WORLD_SCALE)  ] ,
                                                //[   new b2d.b2Vec2(220/WORLD_SCALE, 30/WORLD_SCALE)  ,  new b2d.b2Vec2(3/WORLD_SCALE, 30/WORLD_SCALE)  ,  new b2d.b2Vec2(32/WORLD_SCALE, 27/WORLD_SCALE)  ]
											]}
	
				
		var fixDef = new b2d.b2FixtureDef();
		fixDef.density = 1;
		fixDef.friction = 0.5;
		fixDef.restitution = 0;								
		var bodyDef = new b2d.b2BodyDef();
		bodyDef.type = sprite.D;
		bodyDef.position.x = sprite.x/WORLD_SCALE;
		bodyDef.position.y = sprite.y/WORLD_SCALE;
		bodyDef.userData=sprite;
		var BODY=world.CreateBody(bodyDef);
		
		BODY.GetWorldCenter();
		fixDef.shape = new b2d.b2PolygonShape();
		fixDef.userData=name;
		var points=[];
		for(var  j=0;j<P["POLYGON"].length;j++)
		{
		   for (var i = 0; i < P["POLYGON"][j].length; i++) {
			
				var vec=P["POLYGON"][j][i];
				vec.Set(vec.x-(sprite.image.width/2/WORLD_SCALE), vec.y-(sprite.image.height/2/WORLD_SCALE));
				points[i] = vec;
					
			}
			fixDef.shape.SetAsArray(points, points.length); 
			
			BODY.CreateFixture(fixDef);
			
		}		
		BODY.SetAngle(sprite.angle/(Math.PI*180))	
		sprite.physicsBody=BODY;					
	}
	
	function level345F(sprite,name)
	{
		
		var P={"POLYGON":
		    

                                              [
												 [   new b2d.b2Vec2(6/WORLD_SCALE, 33/WORLD_SCALE)  ,  new b2d.b2Vec2(5/WORLD_SCALE, 6/WORLD_SCALE)  ,  new b2d.b2Vec2(118/WORLD_SCALE, 6/WORLD_SCALE)  ],
												 [   new b2d.b2Vec2(184/WORLD_SCALE, 0/WORLD_SCALE)  ,  new b2d.b2Vec2(224/WORLD_SCALE, 0/WORLD_SCALE)  ,  new b2d.b2Vec2(183/WORLD_SCALE, 30/WORLD_SCALE)  ]
                                               // [   new b2d.b2Vec2(219/WORLD_SCALE, 30/WORLD_SCALE)  ,  new b2d.b2Vec2(188/WORLD_SCALE, 26.5/WORLD_SCALE)  ,  new b2d.b2Vec2(189.5/WORLD_SCALE, 3/WORLD_SCALE)  ,  new b2d.b2Vec2(220/WORLD_SCALE, 2/WORLD_SCALE)  ] ,
                                               // [   new b2d.b2Vec2(118/WORLD_SCALE, 2.5/WORLD_SCALE)  ,  new b2d.b2Vec2(118.5/WORLD_SCALE, 26/WORLD_SCALE)  ,  new b2d.b2Vec2(4/WORLD_SCALE, 29/WORLD_SCALE)  ,  new b2d.b2Vec2(4/WORLD_SCALE, 2/WORLD_SCALE)  ] ,
                                               // [   new b2d.b2Vec2(219/WORLD_SCALE, 30/WORLD_SCALE)  ,  new b2d.b2Vec2(4/WORLD_SCALE, 30/WORLD_SCALE)  ,  new b2d.b2Vec2(188/WORLD_SCALE, 26.5/WORLD_SCALE)  ] ,
                                                //[   new b2d.b2Vec2(4/WORLD_SCALE, 29/WORLD_SCALE)  ,  new b2d.b2Vec2(118.5/WORLD_SCALE, 20/WORLD_SCALE)  ,  new b2d.b2Vec2(120/WORLD_SCALE, 26/WORLD_SCALE)  ]
											]}
	
				
		var fixDef = new b2d.b2FixtureDef();
		fixDef.density = 1;
		fixDef.friction = 0.5;
		fixDef.restitution = 0;								
		var bodyDef = new b2d.b2BodyDef();
		bodyDef.type = sprite.D;
		bodyDef.position.x = sprite.x/WORLD_SCALE;
		bodyDef.position.y = sprite.y/WORLD_SCALE;
		bodyDef.userData=sprite;
		var BODY=world.CreateBody(bodyDef);
		
		BODY.GetWorldCenter();
		fixDef.shape = new b2d.b2PolygonShape();
		fixDef.userData=name;
		var points=[];
		for(var  j=0;j<P["POLYGON"].length;j++)
		{
		   for (var i = 0; i < P["POLYGON"][j].length; i++) {
			
				var vec=P["POLYGON"][j][i];
				vec.Set(vec.x-(sprite.image.width/2/WORLD_SCALE), vec.y-(sprite.image.height/2/WORLD_SCALE));
				points[i] = vec;
					
			}
			fixDef.shape.SetAsArray(points, points.length); 
			
			BODY.CreateFixture(fixDef);
			
		}		
		BODY.SetAngle(sprite.angle/(Math.PI*180))	
		sprite.physicsBody=BODY;					
	}
	//**************L2shape3**********************
	function L2shape3(sprite,name)
	{
		
			var P={"POLYGON":
		[

													[   new b2d.b2Vec2(2/WORLD_SCALE, 62/WORLD_SCALE)  ,  new b2d.b2Vec2(0/WORLD_SCALE, 0/WORLD_SCALE)  ,  new b2d.b2Vec2(31/WORLD_SCALE, 31.5/WORLD_SCALE)  ,  new b2d.b2Vec2(31/WORLD_SCALE, 61/WORLD_SCALE)  ] ,
													[   new b2d.b2Vec2(31/WORLD_SCALE, 31.5/WORLD_SCALE)  ,  new b2d.b2Vec2(0/WORLD_SCALE, 0/WORLD_SCALE)  ,  new b2d.b2Vec2(98/WORLD_SCALE, 0/WORLD_SCALE)  ,  new b2d.b2Vec2(98/WORLD_SCALE, 32/WORLD_SCALE)  ]
												]}
				
		var fixDef = new b2d.b2FixtureDef();
		fixDef.density = 1;
		fixDef.friction = 0.5;
		fixDef.restitution = 0;								
		var bodyDef = new b2d.b2BodyDef();
		bodyDef.type = sprite.D;
		bodyDef.position.x = sprite.x/WORLD_SCALE;
		bodyDef.position.y = sprite.y/WORLD_SCALE;
		bodyDef.userData=sprite;
		var BODY=world.CreateBody(bodyDef);
		
		BODY.GetWorldCenter();
		fixDef.shape = new b2d.b2PolygonShape();
		fixDef.userData=name;
		var points=[];
		for(var  j=0;j<P["POLYGON"].length;j++)
		{
		   for (var i = 0; i < P["POLYGON"][j].length; i++) {
			
				var vec=P["POLYGON"][j][i];
				vec.Set(vec.x-(sprite.image.width/2.2/WORLD_SCALE), vec.y-(sprite.image.height/2.2/WORLD_SCALE));
				points[i] = vec;
					
			}
			fixDef.shape.SetAsArray(points, points.length); 
			
			BODY.CreateFixture(fixDef);
			
		}		
		BODY.SetAngle(sprite.angle/(Math.PI*180))	
		sprite.physicsBody=BODY;					
	}
	
	function  createPolygonBody(sprite,ptype,name)
	{
		if(ptype=="star")
		{
			createPolystar(sprite,name);
		}
		else if(ptype=="L2shape3")
		{
			L2shape3(sprite,name);
		}
		else if(ptype=="level34-5")
		{
			
			level345(sprite,name);
		}
		else if(ptype=="level34-5f")
		{
			
			level345F(sprite,name);
		}
	}
	function createCricleBody(sprite,radius,name)
	{
	//	console.log(sprite.b2BodyDef);
			var bodyDef;
			bodyDef = new b2d.b2BodyDef();
					for (var defkey in sprite.physicsAttributes["b2BodyDef"]) {
					if(typeof bodyDef[defkey] != "undefined" && bodyDef[defkey]!="userData")
					{
						bodyDef[defkey]=sprite.physicsAttributes["b2BodyDef"][defkey];
						
					}
					
			}
			bodyDef.type = sprite.D;
			bodyDef.position.x = (sprite.x)/WORLD_SCALE;
			bodyDef.position.y =(sprite.y)/WORLD_SCALE;
			bodyDef.userData=sprite;
			
			var fixDef = new b2d.b2FixtureDef();
			for (var fixkey in sprite.physicsAttributes["b2FixtureDef"]) {
					
					fixDef[fixkey]=sprite.physicsAttributes["b2FixtureDef"][fixkey];
				}
			fixDef.userData=name;
			fixDef.shape = new b2d.b2CircleShape();
			fixDef.shape.SetRadius(radius/WORLD_SCALE);
			
			var spritephysicsBody=world.CreateBody(bodyDef);
	
			spritephysicsBody.CreateFixture(fixDef);
			
			sprite.physicsBody=spritephysicsBody;

	}
	function createDRectangeleBody(sprite,w,h,name)
	{
		
			var bodyDef;
			
			var fixDef = new b2d.b2FixtureDef();
			fixDef.isSensor  =true;
			fixDef.userData=name;
			fixDef.shape = new b2d.b2PolygonShape();
			fixDef.shape.SetAsOrientedBox((w)/WORLD_SCALE, (h)/WORLD_SCALE,new b2d.b2Vec2(0.0,0.0),0);
	
			bodyDef = new b2d.b2BodyDef();
			bodyDef.userData=sprite;
			bodyDef.type = sprite.D;
			bodyDef.position.Set((sprite.x)/WORLD_SCALE,sprite.y/WORLD_SCALE);
		
			
			
			var spritephysicsBody=world.CreateBody(bodyDef);
			spritephysicsBody.SetAngle(sprite.angle/(Math.PI*180))	
			spritephysicsBody.CreateFixture(fixDef);
			sprite.physicsBody=spritephysicsBody;
			
		
	}
	function createRectangeleBody(sprite,w,h,name)
	{

			var bodyDef;
			//adding fixture defination
			var fixDef = new b2d.b2FixtureDef();
			for (var fixkey in sprite.physicsAttributes["b2FixtureDef"]) {
					
					fixDef[fixkey]=sprite.physicsAttributes["b2FixtureDef"][fixkey];
				}
			fixDef.userData=name;
			fixDef.shape = new b2d.b2PolygonShape();
			fixDef.shape.SetAsOrientedBox((w)/WORLD_SCALE, (h)/WORLD_SCALE,new b2d.b2Vec2(0.0,0.0),0);
			//adding body defination
			bodyDef = new b2d.b2BodyDef();
			for (var defkey in sprite.physicsAttributes["b2BodyDef"]) {
					if(typeof bodyDef[defkey] != "undefined" && bodyDef[defkey]!="userData")
					{
						bodyDef[defkey]=sprite.physicsAttributes["b2BodyDef"][defkey];
						
					}
					
				}
			bodyDef.userData=sprite;
			bodyDef.type = sprite.D;
			bodyDef.position.Set((sprite.x)/WORLD_SCALE,sprite.y/WORLD_SCALE);
		
		//	console.log(bodyDef.userData);
			
			var spritephysicsBody=world.CreateBody(bodyDef);
			spritephysicsBody.SetAngle(sprite.angle/(Math.PI*180))	
			spritephysicsBody.CreateFixture(fixDef);
			sprite.physicsBody=spritephysicsBody;
			
		
	}
	function addDefaultPhysicsWorld()
	{
		var w = stage.canvas.width;
		var h = stage.canvas.height;
		world = new b2d.b2World(new b2d.b2Vec2(0, 20), true);
		//add with debugger
		var debugDraw = new b2d.b2DebugDraw();
		debugDraw.SetSprite(debugCanvas.getContext("2d"));
		debugDraw.SetDrawScale( WORLD_SCALE);
		debugDraw.SetFillAlpha(0.5);
		debugDraw.SetLineThickness(1);
		debugDraw.SetFlags(b2d.b2DebugDraw.e_shapeBit | b2d.b2DebugDraw.e_jointBit);
		world.SetDebugDraw(debugDraw);
		
		
		var fixDef = new b2d.b2FixtureDef();
		fixDef.density = 1;
		fixDef.friction = 0.5;
		fixDef.restitution = 0;
		fixDef.shape = new b2d.b2PolygonShape();
		fixDef.shape.SetAsBox(w/WORLD_SCALE*0.6, 10/WORLD_SCALE);
		var bodyDef = new b2d.b2BodyDef();
		bodyDef.type = b2d.b2Body.b2_staticBody;
		bodyDef.position.x = (w+100)/2/WORLD_SCALE;
		bodyDef.position.y = 574/WORLD_SCALE;
		world.CreateBody(bodyDef).CreateFixture(fixDef);

	}

		



	window.Main = Main;

})();
