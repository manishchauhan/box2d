(function() {

function gameDebugger(root,stageReference) {
	this.root=root;
	this.Container_constructor();
	this.stageReference=stageReference;
	this.setup();
}

var p = createjs.extend(gameDebugger,createjs.Container);
var root;
var DebugText;
var stageReference;
var htmlText;
var offset;
p.setup = function() {
	    
		 this.createDOMElement();
		this.htmllabelText= new createjs.DOMElement(this.htmlText);
		
		this.htmllabelText.x=30;
		this.htmllabelText.y=40;
		this.addChild(this.htmllabelText);
		
		var background = new createjs.Shape();
     	background.graphics.beginFill("#C33").drawRoundRect(5,0,275,30,10);
     	this.addChild(background);
		this.root.updateStage();
		
		this.cursor = "pointer";
		
		this.on("pressmove", function(evt) {
			this.x = evt.stageX + this.offset.x;
			this.y = evt.stageY + this.offset.y;
			this.root.updateStage();
		});
		this.on("mousedown", function (evt) {
				this.offset = {x: this.x - evt.stageX, y: this.y - evt.stageY};
			});
		this.on("pressup", function(evt) {this.cache=false; })
	
} ;


p.createDOMElement=function()
{
	this.htmlText = document.createElement('div');
	this.htmlText.innerHTML ="";
	
	this.htmlText.id = 'ab';
		this.htmlText.style.position = "absolute";
	this.htmlText.style.color="#000";
	this.htmlText.style.height = '250px';
	this.htmlText.style.width = '250px';
	this.htmlText.style.resize= 'both';
	this.htmlText.style.backgroundColor = "white";
	this.htmlText.style.top = 0;
	this.htmlText.style.left = 0;
	this.htmlText.style.overflow='auto';
	document.body.appendChild(this.htmlText);
}

p.Debug=function()
{
	

	
}
p.showsFPS=function()
{
	
}
p.showsDrawCount=function()
{
	
}
window.gameDebugger = createjs.promote(gameDebugger, "Container");
}());