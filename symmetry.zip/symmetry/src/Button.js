(function() {

function Button(label,color,main,clone) {
	
	this.enable=true;
	this.Container_constructor();
	this.clone=clone;
	this.color = color;
	this.label = label;
	this.main=main;
	this.setup();
}
var p = createjs.extend(Button,createjs.Container);
var buttonGraphics;
var labelText;
var enable;
Button.btnname="newbtn";
Button.myfun= function() {
	return "manish chauhan"+1;
}
p.setup = function() {
	
	
	if(this.clone)
	{
		this.buttonGraphics = this.addChild(this.clone);
		this.buttonGraphics.gotoAndStop(0);
	}
	else
	{
		/*
		var background = new createjs.Shape();
		background.graphics.beginFill(this.color).drawRoundRect(0,0,width,height,10);
		this.addChild(background, text); 
		this.offset = Math.random()*10;
		this.count = 0;*/
		
	}

	this.addLabelText();
	
	
	//this.on("click", this.handleClick);
	this.on("rollover", this.handleRollOver);
	this.on("rollout", this.handleRollOver);
	this.cursor = "pointer";
	this.mouseChildren = false;
} ;

p.addLabelText=function()
{
	this.labelText = new createjs.Text(this.label, "20px Arial", "#000");
	this.labelText.textBaseline = "top";
	this.labelText.textAlign = "center";
	var width = this.labelText.getMeasuredWidth()+30;
	var height = this.labelText.getMeasuredHeight()+20;
	this.labelText.x = 0;
	this.labelText.y = -10;
	this.addChild(this.labelText);
	
	
}


//[{text:"my label#mathid"}]
p.handleRollOver = function(event) {     
    

     if(this.clone)
	 {
		 
		  event.type == "rollover" ?  this.buttonGraphics.gotoAndStop(1) : this.buttonGraphics.gotoAndStop(0);
		 
	 }
	  else
	  {
		  this.alpha = event.type == "rollover" ? 0.4 : 1;
	  }
		
	
};

window.Button = createjs.promote(Button, "Container");
}());